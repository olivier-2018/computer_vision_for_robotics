function I = warpImage(I_R, W)
% TODO: Your code here

end

